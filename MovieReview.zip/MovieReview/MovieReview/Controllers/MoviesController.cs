﻿using Microsoft.AspNetCore.Mvc;
using MoviesList.Models;
using MoviesList.Repository;

namespace MoviesList.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class MoviesController : ControllerBase
    {
        private readonly IMoviesRepository _moviesRepository;

        public MoviesController(IMoviesRepository moviesRepository)
        {
            _moviesRepository = moviesRepository;
        }

        [HttpGet]
        public IEnumerable<Movie> GetMovies()
        {
            IEnumerable<Movie> movies = _moviesRepository.GetAllMovies();

            if(movies == null)
            {
                return Enumerable.Empty<Movie>();
            }

            return movies;
        }

        [HttpGet("{id}")]
        public Movie? GetMoviesByID(Guid id)
        {
            var movie = _moviesRepository.GetMovieById(id);

            if(movie == null)
            {
                return null;
            }

            return movie;
        }

        [HttpPost]
        public Movie? createMovie([FromBody]Movie movie)
        {
            var result = _moviesRepository.CreateMovie(movie);

            if(result == null)
            {
                return null;
            }

            return result;

        }

        [HttpPut]
        public Movie? updateMovie([FromBody] Movie movie)
        {
            var result = _moviesRepository.UpdateMovie(movie);

            if (result == null)
            {
                return null;
            }

            return result;

        }
    }
}
