﻿using Microsoft.AspNetCore.Mvc;
using MovieReview.Repository.Interface;
using MoviesList.Models;

namespace MovieReview.Controllers
{

    [ApiController]
    [Route("api/[controller]")]
    public class ActorController : ControllerBase
    {

        private readonly IActorRepository _actorRepository;

        public ActorController(IActorRepository actorRepository)
        {
            _actorRepository = actorRepository;
        }

        [HttpGet]
        public IEnumerable<Actor> GetAllActors()
        {
            IEnumerable<Actor> actors = _actorRepository.GetActors();

            if (actors == null)
            {
                return Enumerable.Empty<Actor>();
            }

            return actors;
        }

        [HttpGet("{id}")]
        public Actor? GetActorByID(Guid id)
        {
            var actor = _actorRepository.GetActorByID(id);

            if (actor == null)
            {
                return null;
            }

            return actor;
        }

        [HttpPost]
        public Actor? CreateActor([FromBody] Actor actor)
        {
            var result = _actorRepository.CreateActor(actor);

            if (result == null)
            {
                return null;
            }

            return result;

        }

        [HttpDelete]
        public Actor? DeleteActor([FromBody] Guid id)
        {
            var result = _actorRepository.DeleteActor(id);

            if (result == null)
            {
                return null;
            }

            return result;

        }

        [HttpPut]
        public Actor? updateActor([FromBody] Actor actor)
        {
            var result = _actorRepository.UpdateActor(actor);

            if (result == null)
            {
                return null;
            }

            return result;

        }
    }
}
