﻿using Microsoft.AspNetCore.Mvc;
using MovieReview.Repository.Interface;
using MoviesList.Models;

namespace MovieReview.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ProducerController : ControllerBase
    {
        private readonly IProducerRepository _producerRepository;

        public ProducerController(IProducerRepository producerRepository)
        {
            _producerRepository = producerRepository;
        }

        [HttpGet]
        public IEnumerable<Producer> GetAllProducers()
        {
            IEnumerable<Producer> producers = _producerRepository.GetProducers();

            if (producers == null)
            {
                return Enumerable.Empty<Producer>();
            }

            return producers;
        }

        [HttpGet("{id}")]
        public Producer? GetProducerByID(Guid id)
        {
            var producer = _producerRepository.GetProducerByID(id);

            if (producer == null)
            {
                return null;
            }

            return producer;
        }

        [HttpPost]
        public Producer? CreateProducer([FromBody] Producer producer)
        {
            var result = _producerRepository.CreateProducer(producer);

            if (result == null)
            {
                return null;
            }

            return result;

        }

        [HttpDelete]
        public Producer? DeleteProducer([FromBody] Guid id)
        {
            var result = _producerRepository.DeleteProducer(id);

            if (result == null)
            {
                return null;
            }

            return result;

        }

        [HttpPut]
        public Producer? updateProducer([FromBody] Producer producer)
        {
            var result = _producerRepository.UpdateProducer(producer);

            if (result == null)
            {
                return null;
            }

            return result;

        }
    }
}
