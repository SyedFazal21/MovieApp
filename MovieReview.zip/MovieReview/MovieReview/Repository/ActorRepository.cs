﻿using Microsoft.EntityFrameworkCore;
using MovieReview.Repository.Interface;
using MoviesList.Models;

namespace MovieReview.Repository
{
    public class ActorRepository : IActorRepository
    {

        private readonly ApplicationContext _context;

        public ActorRepository(ApplicationContext context)
        {
            _context = context;
        }

        public Actor? CreateActor(Actor actor)
        {
            if (actor == null)
            {
                return null;
            }

            actor.ID = Guid.NewGuid();

            _context.Actors.Add(actor);
            _context.SaveChanges();
            return actor;
        }

        public Actor? DeleteActor(Guid id)
        {
            var actor = _context.Actors.FirstOrDefault(x => x.ID == id);

            if (actor == null)
            {
                return null;
            }

            _context.Actors.Remove(actor);
            _context.SaveChanges();
            return actor;
        }

        public Actor? GetActorByID(Guid id)
        {
            Actor? actor = _context.Actors.Find(id);

            if (actor == null)
            {
                return null;
            }

            return actor;
        }

        public IEnumerable<Actor> GetActors()
        {
            IEnumerable<Actor> actors = _context.Actors.ToList();
            return actors;
        }

        public Actor? UpdateActor(Actor actor)
        {
            try
            {
                _context.Entry(actor).State = EntityState.Modified;
                _context.SaveChanges();
                return actor;
            }
            catch
            {
                return null;
            }
        }
    }
}
