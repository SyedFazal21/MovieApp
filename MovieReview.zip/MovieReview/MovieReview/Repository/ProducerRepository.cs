﻿using Microsoft.EntityFrameworkCore;
using MovieReview.Repository.Interface;
using MoviesList.Models;

namespace MovieReview.Repository
{
    public class ProducerRepository : IProducerRepository
    {

        private readonly ApplicationContext _context;

        public ProducerRepository(ApplicationContext context)
        {
            _context = context;
        }

        public Producer? CreateProducer(Producer producer)
        {
            if (producer == null)
            {
                return null;
            }

            producer.ID = Guid.NewGuid();

            _context.Producers.Add(producer);
            _context.SaveChanges();
            return producer;
        }

        public Producer? DeleteProducer(Guid id)
        {
            var producer = _context.Producers.FirstOrDefault(x => x.ID == id);

            if (producer == null)
            {
                return null;
            }

            _context.Producers.Remove(producer);
            _context.SaveChanges();
            return producer;
        }

        public IEnumerable<Producer> GetProducers()
        {
            IEnumerable<Producer> producer = _context.Producers.ToList();
            return producer;
        }

        public Producer? GetProducerByID(Guid id)
        {
            Producer? producer = _context.Producers.Find(id);

            if (producer == null)
            {
                return null;
            }

            return producer;
        }

        public Producer? UpdateProducer(Producer producer)
        {
            try
            {
                _context.Entry(producer).State = EntityState.Modified;
                _context.SaveChanges();
                return producer;
            }
            catch
            {
                return null;
            }
        }
    }
}
