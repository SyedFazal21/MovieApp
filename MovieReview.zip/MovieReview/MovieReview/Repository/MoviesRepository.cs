﻿using Microsoft.EntityFrameworkCore;
using MovieReview.Models;
using MoviesList.Models;

namespace MoviesList.Repository
{
    public class MoviesRepository : IMoviesRepository
    {

        private readonly ApplicationContext _context;

        public MoviesRepository(ApplicationContext context)
        {
            _context = context;
        }

        public Movie? CreateMovie(Movie movie)
        {
            if(movie == null)
            {
                return null;
            }

            movie.ID = Guid.NewGuid();

            foreach (string actor in movie.Actors)
            {
                // Adding in movie and actor mapper table
                _context.MovieActorMap.Add(new MovieActorMapper()
                {
                    ID = Guid.NewGuid(),
                    MovieID = movie.ID,
                    ActorName = actor,
                });
            }

            // Add Movie into Movies table
            _context.Movies.Add(movie);
            _context.SaveChanges();
            return movie;
        }

        public IEnumerable<Movie> GetAllMovies()
        {
            IEnumerable<Movie> movies = _context.Movies.ToList();

            foreach (var movie in movies)
            {
                movie.Actors = _context.MovieActorMap
                .Where(p => p.MovieID == movie.ID)
                .Select(p => p.ActorName);
            }

            return movies;
        }

        public Movie? GetMovieById(Guid id)
        {
            Movie? movie = _context.Movies.Find(id);

            if(movie == null)
            {
                return null;
            }

            movie.Actors = _context.MovieActorMap
                .Where(p => p.MovieID == id)
                .Select(p => p.ActorName);

            return movie;
        }

        public Movie? UpdateMovie(Movie movie)
        {
            try
            {
                _context.Entry(movie).State = EntityState.Modified;
                _context.SaveChanges();
                return movie;
            }
            catch
            {
                return null;
            }
            
        }
    }
}
