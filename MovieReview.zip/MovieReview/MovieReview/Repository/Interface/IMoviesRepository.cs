﻿using MoviesList.Models;

namespace MoviesList.Repository
{
    public interface IMoviesRepository
    {
        Movie? CreateMovie(Movie movie);
        Movie? UpdateMovie(Movie movie);
        IEnumerable<Movie> GetAllMovies();
        Movie? GetMovieById(Guid id);
    }
}
