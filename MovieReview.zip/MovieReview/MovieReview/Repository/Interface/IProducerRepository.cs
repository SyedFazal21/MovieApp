﻿using MoviesList.Models;

namespace MovieReview.Repository.Interface
{
    public interface IProducerRepository
    {
        public IEnumerable<Producer> GetProducers();
        public Producer? CreateProducer(Producer producer);
        public Producer? UpdateProducer(Producer producer);
        public Producer? DeleteProducer(Guid id);
        public Producer? GetProducerByID(Guid id);
    }
}
