﻿using MoviesList.Models;

namespace MovieReview.Repository.Interface
{
    public interface IActorRepository
    {
        public IEnumerable<Actor> GetActors();
        public Actor? CreateActor(Actor actor);
        public Actor? UpdateActor(Actor actor);
        public Actor? DeleteActor(Guid actor);
        public Actor? GetActorByID(Guid id);
    }
}
