﻿
using Swashbuckle.AspNetCore.Annotations;
using System.ComponentModel.DataAnnotations;

namespace MoviesList.Models
{
    public class Producer
    {
        [SwaggerSchema(ReadOnly = true)]
        public Guid ID { get; set; }
        [Required]
        public string Name { get; set; } = string.Empty;
        [Required]
        public string Bio { get; set; } = string.Empty;
        [Required]
        public string Company { get; set; } = string.Empty;
        [Required]
        public string Gender { get; set; } = string.Empty;
        [Required]
        public string DateOfBirth { get; set; } = string.Empty;
    }
}
