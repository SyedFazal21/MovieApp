﻿
using Swashbuckle.AspNetCore.Annotations;

namespace MoviesList.Models
{
    public class Actor
    {
        [SwaggerSchema(ReadOnly = true)]
        public Guid ID { get; set; }
        public string Name { get; set; } = string.Empty;
        public string Bio { get; set; } = string.Empty;
        public string Gender { get; set; } = string.Empty;
        public string DateOfBirth { get; set; } = string.Empty;
    }
}
