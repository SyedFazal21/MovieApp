﻿using Microsoft.EntityFrameworkCore;
using MovieReview.Models;

namespace MoviesList.Models
{
    public class ApplicationContext : DbContext
    {

        public ApplicationContext(DbContextOptions<ApplicationContext> options) : base(options)
        {
        }


        //Creating tables in the DB
        public DbSet<Actor> Actors { get; set; }

        public DbSet<Producer> Producers { get; set; }

        public DbSet<Movie> Movies { get; set; }

        public DbSet<MovieActorMapper> MovieActorMap { get; set; }

    }
}
