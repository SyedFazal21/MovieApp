﻿
using Swashbuckle.AspNetCore.Annotations;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MoviesList.Models
{
    public class Movie
    {
        [SwaggerSchema(ReadOnly = true)]
        public Guid ID { get; set; }
        [Required]
        public string MovieName { get; set; } = string.Empty;
        [Required]
        public string Plot { get; set; } = string.Empty;
        [Required]
        public string DateOfRelease { get; set; } = string.Empty;
        [Required]
        public string Poster { get; set; } = string.Empty;
        [Required]
        public string ProducerName { get; set; }

        [NotMapped]
        public IEnumerable<string> Actors { get; set; }
    }
}
