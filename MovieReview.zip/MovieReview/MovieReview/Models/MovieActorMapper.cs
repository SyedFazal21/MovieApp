﻿using Swashbuckle.AspNetCore.Annotations;

namespace MovieReview.Models
{
    public class MovieActorMapper
    {
        [SwaggerSchema(ReadOnly = true)]
        public Guid ID { get; set; }
        public Guid MovieID { get; set; }
        public string ActorName { get; set; } = string.Empty;
    }
}
